"""SP Database MCP Server - 实时数据库表结构信息服务"""

__version__ = "0.1.0"
